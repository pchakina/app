from typing import Any

from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


@singleton
class TransformationStep(BaseStep):
    type = "transformer"

    TRANSFORM_CONFIG = "transform_config"
    DELETE_CONFIG = "delete_config"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any)->Any:
        step_config = step_context.step_config
        if self.TRANSFORM_CONFIG in step_config.config:
            transform_config = step_config.config[self.TRANSFORM_CONFIG]
            payload = self.payload_transformer.transform(transform_config, payload)

        # add support for deleting keys
        if self.DELETE_CONFIG in step_config.config:
            delete_config = step_config.config[self.DELETE_CONFIG]
            for item in delete_config:
                path_items = item.split(".")

        return payload
