from typing import Any

import traceback

from data_loader.core.config_manager import ConfigManager
from data_loader.core.dto import Pipeline
from injector import singleton, Injector
from material.plugins.search.config import pipeline

from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext
from data_loader.core.step_manager import StepManager
from data_loader.core.util.config_util import ConfigUtil
from data_loader.core.util.yaml_util import YamlUtil


@singleton
class PipelineManager:
    injector = Injector()

    def __init__(self):
        self.step_manager = self.injector.get(StepManager)
        self.config_manager = self.injector.get(ConfigManager)
        self.load(ConfigUtil.get_pipeline_config_path())

    def load(self, file_name):
        data = YamlUtil.load_yaml(file_name)
        configs = []
        for item in data:
            config = Pipeline(**item)
            configs.append(config)

        for config in configs:
            for scriptlet in config.scriptlets.values():
                exec(scriptlet)

        self.config_manager.pipelines = configs
        print(self.config_manager.pipelines)

    def execute(self, code: str, payload: Any) -> str:
        print("Executing pipeline")
        pipeline = self.__get_pipeline_config(code)
        self.__execute(pipeline, payload)

    def execute_by_version(self, code: str, version: str, payload: Any) -> str:
        print("Executing pipeline")
        pipeline = self.__get_pipeline_config_by_version(code, version)
        self.__execute(pipeline, payload)

    def __execute(self, pipeline: Pipeline, payload: Any):
        pipeline_context = PipelineContext()
        step_context = StepContext()
        step_context.pipeline = pipeline
        steps = pipeline.steps
        config = pipeline.config
        pipeline_context.config = config
        pipeline_context.request = payload
        pipeline_context.pipeline_config = pipeline
        except_steps = pipeline.except_steps
        response = "OK"
        new_payload = payload
        try:
            for step in steps:
                step_context.step_config = step
                new_payload = self.step_manager.execute(step, pipeline_context, step_context, new_payload)
            return new_payload
        except:
            traceback.print_exc()
            for step in except_steps:
                step_context.step_config = step
                new_payload = self.step_manager.execute(step, pipeline_context, step_context, new_payload)
            return new_payload


    def __get_pipeline_config(self, code: str)->Pipeline:
        for item in self.config_manager.pipelines:
            if code == item.endpoint:
                return item
        return None


    def __get_pipeline_config_by_version(self, code: str, version: str)->Pipeline:
        for item in self.config_manager.pipelines:
            if code == item.endpoint and version == item.version:
                return item
        return None


if __name__ == '__main__':
    manager = PipelineManager()
    data = manager.load("pipeline.yml")
    payload = ""
    manager.execute(payload)
