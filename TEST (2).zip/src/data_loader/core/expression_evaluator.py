import json
from typing import Any

from injector import singleton
from jsonpath_ng import jsonpath, parse

from data_loader.core.util.constants import STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_TYPE, \
    STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_CUSTOM, STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_EXPR, \
    STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_PATH, STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_VALUE, \
    STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH, STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_OP, \
    STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_OP_EQUALS, STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_OP_IN, \
    STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_OP_NOT_EQUALS


@singleton
class ExpressionEvaluator:


    def evaluate(self, config: dict, payload: str)->bool:
        type = config[STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_TYPE]
        if type == STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_CUSTOM:
            return eval(config[STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_EXPR])
        else:
            path_exprs = config[STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_EXPR]
            ret_val = None
            for path_expr in path_exprs:
                path_cfg = path_expr[STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_PATH]
                value_cfg = path_expr[STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_VALUE]
                op_cfg = path_expr[STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_OP]
                jsonpath_expr = parse(path_cfg)
                rets = jsonpath_expr.find(payload)
                if op_cfg == STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_OP_IN:
                    ret_val = str(value_cfg).lower() in rets
                else:
                    for ret in rets:
                        ret_val = self.__do_operation(op_cfg, str(value_cfg).lower(), str(ret.value).lower())
                return ret_val
            return ret_val

    def __do_operation(self, op_code: str, actual_val: str, expected_val:str)->bool:
        if op_code == STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_OP_EQUALS:
            return actual_val == expected_val
        elif op_code == STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH_OP_NOT_EQUALS:
            return actual_val != expected_val


if __name__ == '__main__':

    with open("db.json", 'r') as json_file:
        json_data = json.load(json_file)

    expr = "jsonpath(\"$.id\")"
    print(json_data)

    jsonpath_expression = parse('employees[*].id')
    rets = jsonpath_expression.find(json_data)

    for match in rets:
        print(f'Employee id: {match.value}')

    config = dict()
    config["type"] = STEP_CONFIG_PASS_THRU_CONFIG_EXPR_EVAL_JSONPATH
    exprs = list()
    exprs.append({"path":'employees[*].id', "value":"1"})
    config["expr"] = exprs

    print(ExpressionEvaluator.evaluate(config, json_data))
