import json


class dto:
    pass

    @classmethod
    def from_json(cls, string: str):
        data: dict = json.loads(string)
        return cls(**data)

    def json(self):
        return json.dumps(self, default=lambda o: o.__dict__)


VALIDATOR = "VALIDATOR"
TRANSFORMER = "TRANSFORMER"


class Step(dto):
    name: str
    type: str
    config: dict

    def __init__(self, **entries):
        self.__dict__.update(entries)


class Pipeline(dto):
    name: str
    endpoint: str
    version: str
    steps: list[Step]
    except_steps: list[Step]
    scriptlets: dict

    def __init__(self, **entries):
        self.__dict__.update(entries)
        steps = list()
        for step_dict in self.steps:
            step = Step(**step_dict)
            steps.append(step)
        except_steps = list()
        for step_dict in self.except_steps:
            step = Step(**step_dict)
            except_steps.append(step)
        self.steps = steps
        self.except_steps = except_steps
