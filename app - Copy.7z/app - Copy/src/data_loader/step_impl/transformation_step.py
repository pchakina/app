from typing import Any

from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


@singleton
class TransformationStep(BaseStep):
    type = "transformer"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any):
        print("In TransformationStep")
