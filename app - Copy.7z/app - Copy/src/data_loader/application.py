from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from data_loader.core.database import session_manager
from data_loader.rest import user_resource, pipeline_resource

app = FastAPI()

app.include_router(user_resource.router, prefix="/user", tags=["/user"])
app.include_router(pipeline_resource.router, prefix="/pipeline", tags=["/pipeline"])


@app.exception_handler(Exception)
async def entity_not_found_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_404_NOT_FOUND,
        content={"detail": f"{exc.detail}"}
    )


# bind SQL tables to App
@app.on_event("startup")
def on_startup():
    session_manager.create_db_and_tables()
