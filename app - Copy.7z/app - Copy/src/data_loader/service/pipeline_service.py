from injector import singleton, Injector

from data_loader.core.pipeline_manager import PipelineManager


@singleton
class PipelineService(object):
    def __init__(self):
        self.injector = Injector()
        self.pipeline_manager = self.injector.get(PipelineManager)

    def process(self, payload: str) -> str:
        resp = self.pipeline_manager.execute(payload)
        return resp
