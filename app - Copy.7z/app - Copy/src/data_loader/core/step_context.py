from data_loader.core.dto import Pipeline


class StepContext:
    params: dict
    pipeline: Pipeline
