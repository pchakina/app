from typing import Any

from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


class BaseStep:
    type: str = "NA"

    def init(self):
        pass

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any):
        pass

    def destroy(self):
        pass
