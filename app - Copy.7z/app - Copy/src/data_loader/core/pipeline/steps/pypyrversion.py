"""Step that echos data_loader.core.pipeline version."""
import logging

import data_loader.core.pipeline.version

# logger means the log level will be set correctly
logger = logging.getLogger(__name__)


def run_step(context):
    """Output data_loader.core.pipeline version in format 'data_loader.core.pipeline x.y.z python a.b.c'."""
    logger.debug("started")

    logger.notify(data_loader.core.pipeline.version.get_version())

    logger.debug("done")
