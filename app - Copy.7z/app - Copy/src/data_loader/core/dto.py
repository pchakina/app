import json


class dto:
    pass

    @classmethod
    def from_json(cls, string: str):
        data: dict = json.loads(string)
        return cls(**data)

    def json(self):
        return json.dumps(self, default=lambda o: o.__dict__)


VALIDATOR = "VALIDATOR"
TRANSFORMER = "TRANSFORMER"


class Step(dto):
    name: str
    type: str
    params: dict

    def __init__(self, **entries):
        self.__dict__.update(entries)


class Pipeline(dto):
    name: str
    steps: list[Step]

    def __init__(self, **entries):
        self.__dict__.update(entries)
        steps = list()
        for step_dict in self.steps:
            step = Step(**step_dict)
            steps.append(step)
        self.steps = steps
