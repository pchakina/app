from typing import Any

from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


class CustomPython:

    def __init__(self):
        print("In constructor")

    def handle_custom(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any):
        print("in handle custom")