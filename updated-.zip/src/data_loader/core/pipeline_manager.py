from typing import Any

from multipledispatch import dispatch
import traceback

from data_loader.core.config_manager import ConfigManager
from data_loader.core.dto import Pipeline
from injector import singleton, Injector

from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext
from data_loader.core.step_manager import StepManager
from data_loader.core.util.config_util import ConfigUtil
from data_loader.core.util.yaml_util import YamlUtil


@singleton
class PipelineManager:
    injector = Injector()

    def __init__(self):
        self.step_manager = self.injector.get(StepManager)
        self.step_manager.pipeline_manager = self
        self.config_manager = self.injector.get(ConfigManager)
        self.load(ConfigUtil.get_pipeline_config_path())

    def load(self, file_name):
        data = YamlUtil.load_yaml(file_name)
        configs = []
        for item in data:
            config = Pipeline(**item)
            configs.append(config)

        for config in configs:
            if hasattr(config, "scriptlets"):
                for scriptlet in config.scriptlets.values():
                    exec(scriptlet)

        self.config_manager.pipelines = configs
        print(self.config_manager.pipelines)

    @dispatch(str, dict)
    def execute(self, code: str, payload: dict) -> str:
        print("Executing pipeline")
        pipeline = self.get_pipeline_config(code)
        self.execute(pipeline, payload)

    @dispatch(str, str, dict)
    def execute(self, code: str, version: str, payload: dict) -> str:
        print("Executing pipeline")
        pipeline = self.get_pipeline_config(code, version)
        if pipeline is None:
            return payload
        self.execute(pipeline, payload)

    @dispatch(Pipeline, dict)
    def execute(self, pipeline: Pipeline, payload: dict):
        pipeline_context = PipelineContext()
        step_context = StepContext()
        step_context.pipeline = pipeline
        if not hasattr(pipeline, "steps"):
            return payload
        steps = pipeline.steps
        config = pipeline.config
        pipeline_context.config = config
        pipeline_context.request = payload
        pipeline_context.pipeline_config = pipeline
        pipeline_context.pipeline_manager = self.step_manager.pipeline_manager
        except_steps = list()
        if hasattr(pipeline, "except_steps"):
            except_steps = pipeline.except_steps
        response = "OK"
        return self.execute(pipeline, pipeline_context, step_context, payload)


    @dispatch(str, str, PipelineContext, StepContext, dict)
    def execute(self, code: str, version: str, pipeline_context: PipelineContext, step_context: StepContext, payload: dict):
        pipeline = self.get_pipeline_config(code, version)
        return self.execute(pipeline, pipeline_context, step_context, payload)

    @dispatch(Pipeline, PipelineContext, StepContext, dict)
    def execute(self, pipeline: Pipeline, pipeline_context: PipelineContext, step_context: StepContext, payload: dict):
        new_payload = payload
        try:
            for step in pipeline.steps:
                step_context.step_config = step
                new_payload = self.step_manager.execute(step, pipeline_context, step_context, new_payload)
            return new_payload
        except:
            traceback.print_exc()
            for step in pipeline.except_steps:
                step_context.step_config = step
                new_payload = self.step_manager.execute(step, pipeline_context, step_context, new_payload)
            return new_payload

    @dispatch(str)
    def get_pipeline_config(self, code: str)->Pipeline:
        for item in self.config_manager.pipelines:
            if code == item.endpoint:
                return item
        return None

    @dispatch(str, str)
    def get_pipeline_config(self, code: str, version: str)->Pipeline:
        for item in self.config_manager.pipelines:
            if code == item.endpoint and version == item.version:
                return item
        return None


if __name__ == '__main__':
    manager = PipelineManager()
    data = manager.load("pipeline.yml")
    payload = ""
    manager.execute(payload)
