import os


class ConfigUtil:

    @staticmethod
    def get_pipeline_config_path():
        config_path = os.getenv("PIPELINE_CONFIG")
        return config_path + os.path.sep + "pipeline.yml"
