import json

from injector import singleton, Injector

from data_loader.core.pipeline_manager import PipelineManager
import ast


@singleton
class PipelineService(object):
    def __init__(self):
        self.injector = Injector()
        self.pipeline_manager = self.injector.get(PipelineManager)

    def process(self, code: str, payload: str) -> str:
        payload_dict = json.loads(payload)
        resp = self.pipeline_manager.execute(code, payload_dict)
        return resp

    def process_by_version(self, code: str, version: str, payload: str) -> str:
        payload_dict = json.loads(payload)
        resp = self.pipeline_manager.execute(code, version, payload_dict)
        return resp

