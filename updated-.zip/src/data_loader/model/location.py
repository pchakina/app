class PracticeLocation:
    def __init__(self) -> None:
        pass


def createPracticeLocation(inputPayload):
    payload = {
        "practiceID": inputPayload.get("practitioner").get("fetch_db_details").get("PracticeID"),
        "npiAuthorized": inputPayload.get('npiAuthorized'),
        "application": inputPayload.get('application'),
        "practiceName": inputPayload.get('practiceName'),
        "practiceCode": inputPayload.get('practiceCode'),
        "practiceTypeID": inputPayload.get("practitioner").get("practice").get("practicetypeid"),
        "practiceTypeName": inputPayload.get("practitioner").get("practice").get("practiceTypeName"),
        "locationName": inputPayload.get("practitioner").get("fetch_db_details").get("LocationName"),
        "locationCode": inputPayload.get("practitioner").get("fetch_db_details").get("LocationCode"),
        "locationTypeID": inputPayload.get('locationTypeID'),
        "locationTypeName": inputPayload.get('locationTypeName'),
        "dateFrom": inputPayload.get('dateFrom'),
        "dateTo": inputPayload.get('dateTo'),
        "addressID": inputPayload.get("practitioner").get("fetch_db_details").get("addressid"),
        "zipCodeID": inputPayload.get('zipCodeID'),
        "nationalProviderID": inputPayload.get('nationalProviderID'),
        "archived": "N"
    }
    print(payload)


def createPractitionerLocation(inputPayload):
    payload = {
        "practitionerID": inputPayload.get('practitionerID'),
        "locationID": inputPayload.get('locationID'),
        "addressID": inputPayload.get('addressID'),
        "zipCodeID": inputPayload.get('zipCodeID'),
        "practiceID": inputPayload.get('practiceID'),
        "practiceName": inputPayload.get('practiceName'),
        "practiceTypeID": inputPayload.get('practiceTypeID'),
        "addressTypeID": inputPayload.get('addressTypeID'),
        "addressTypeName": inputPayload.get('addressTypeName'),
        "dateFrom": inputPayload.get('dateFrom'),
        "archived": inputPayload.get('archived'),
        "lineNumber1": inputPayload.get('lineNumber1')
    }
