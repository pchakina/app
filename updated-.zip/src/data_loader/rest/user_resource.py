from typing import Annotated

from fastapi import APIRouter, Depends, status

from data_loader.service.user_service import UserService

router = APIRouter()

userService = Annotated[UserService, Depends(UserService)]


@router.get("/")
def get_list(user_service: userService):
    return user_service.get_users()


@router.get("/{user_id}")
def get_by_id(user_id: int, user_service: userService):
    return user_service.get_user_by_id(user_id)


@router.post("/", status_code=status.HTTP_201_CREATED)
def add(user_service: userService):
    return user_service.create_user()


@router.get("/status")
def get_status():
    return {"status": "OK"}
