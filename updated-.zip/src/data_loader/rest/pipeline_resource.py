import os
from typing import Any

from fastapi import APIRouter, status, Request, Depends
from injector import Injector
import json
from pprint import pprint

from data_loader.service.pipeline_service import PipelineService

router = APIRouter()
injector = Injector()

pipelineService = injector.get(PipelineService)


async def get_body(request: Request):
    return await request.body()

@router.post("/{code}", status_code=status.HTTP_201_CREATED)
def process(code: str, payload: Any):
    resp = pipelineService.process(code, payload)
    return resp


@router.post("/{code}/version/{version}", status_code=status.HTTP_201_CREATED)
def process_by_version(code: str, version: str, content = Depends(get_body)):
    resp = pipelineService.process_by_version(code, version, content.decode("utf-8"))
    return resp

@router.get("/test", status_code=status.HTTP_201_CREATED)
def test_payload():
    resp = "{}"
    with open(os.getcwd()+os.path.sep+'test.json') as json_data:
        resp = json.load(json_data)
        json_data.close()
        pprint(resp)
    return resp
