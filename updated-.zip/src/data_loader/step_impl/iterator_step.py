import json
from typing import Any

from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext
from jsonpath_ng import jsonpath, parse


@singleton
class IteratorStep(BaseStep):
    type = "iterator"
    COLLECTION_PATH = "array_path"
    PIPELINE = "pipeline"
    VERSION = "version"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any):
        step_config = step_context.step_config.config
        pipeline_manager = pipeline_context.pipeline_manager
        collection_path = step_config[self.COLLECTION_PATH]
        json_expr = parse(collection_path)
        pipeline = step_config[self.PIPELINE]
        version = str(step_config[self.VERSION])

        items = json_expr.find(payload)
        for item in items:
            itemvlaue = item.value[0]
            resp = pipeline_manager.execute(pipeline, version, pipeline_context, step_context, itemvlaue)
            print("Received response in iterator: ", resp)
        print("logging payload with name: " + step_context.step_config.name + " >>>> " + json.dumps(payload))
        return payload
