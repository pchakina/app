import importlib
import json

from typing import Any

from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


@singleton
class PythonStep(BaseStep):
    type = "python"

    MODULE = "module"

    def __init__(self):
        super().__init__()

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any):
        print("In PythonStep")
        print("received payload: " + json.dumps(payload))
        step_config = step_context.step_config.config
        module_path = step_config[self.MODULE]
        module_name, func_name = module_path.rsplit(":", 1)
        module_name, class_name = module_name.rsplit(".", 1)
        custom_mod = importlib.import_module(module_name)
        custom_obj = getattr(custom_mod, class_name)()
        func_ref = getattr(custom_obj, func_name)
        return func_ref(pipeline_context, step_context, payload)


if __name__ == '__main__':
    step = PythonStep()
    config = dict()
    config[PythonStep.MODULE] = "data_loader.custom_python.CustomPython:handle_custom"
    step_context = StepContext()
    step_context.config = config
    step.execute(PipelineContext(), step_context, "")
