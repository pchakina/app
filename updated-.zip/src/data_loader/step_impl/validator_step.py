import json
from typing import Any
from jsonschema import validate, ValidationError
from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


@singleton
class ValidatorStep(BaseStep):
    type = "validator"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any)->Any:
        print("In validator")
        print("received payload: " + json.dumps(payload))
        step_config = step_context.step_config
        if "schema" in step_config.config:
            schema_str = step_config.config["schema"]
            validator_schema = json.loads(schema_str)
            try:
                validate(instance=payload, schema=validator_schema)
                print("JSON payload is valid!")
                payload["status"] = "Success"
            except ValidationError as e:
                error_message = f"JSON payload is invalid: {e.message}"
                print("JSON payload is invalid:", e.message)
                payload["status"] = "Failed"
                raise ValueError(error_message)
        return payload
