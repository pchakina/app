import json
from typing import Any

from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext


@singleton
class LogStep(BaseStep):
    type = "log"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any):
        print("logging payload with name: "+ step_context.step_config.name +" >>>> " + json.dumps(payload))
        return payload