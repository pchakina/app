import json

from injector import singleton, Injector

from data_loader.core.pipeline_manager import PipelineManager
import ast


@singleton
class PipelineService(object):
    def __init__(self):
        self.injector = Injector()
        self.pipeline_manager = self.injector.get(PipelineManager)

    def process(self, payload: str) -> str:
        payload_dict = json.loads(payload)
        resp = self.pipeline_manager.execute(payload_dict)
        return resp
