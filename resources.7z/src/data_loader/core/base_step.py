from typing import Any

from injector import Injector

from data_loader.core.expression_evaluator import ExpressionEvaluator
from data_loader.core.payload_transformer import PayloadTransformer
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext

from data_loader.core.util.constants import STEP_CONFIG_PASS_THRU_CONFIG


class BaseStep:
    type: str = "NA"
    pass_through: str
    injector = Injector()
    expression_evaluator: ExpressionEvaluator
    payload_transformer: PayloadTransformer

    def __init__(self):
        self.expression_evaluator = self.injector.get(ExpressionEvaluator)
        self.payload_transformer = self.injector.get(PayloadTransformer)

    def init(self):
        pass

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any) -> str:
        pass

    def execute(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any) -> str:
        retval = True
        step_config = step_context.step_config
        if hasattr(step_config, "config"):
            config = step_config.config
            if STEP_CONFIG_PASS_THRU_CONFIG in config:
                expr_config = step_config.config[STEP_CONFIG_PASS_THRU_CONFIG]
                retval = self.expression_evaluator.evaluate(expr_config, payload)
        if retval:
            return self.process(pipeline_context, step_context, payload)

    def destroy(self):
        pass
