"""Step that stops current pipeline."""
import logging

from data_loader.core.pipeline.errors import StopPipeline

# logger means the log level will be set correctly
logger = logging.getLogger(__name__)


def run_step(context):
    """Stop current pipeline."""
    logger.debug("started")

    logger.info("StopPipeline: stopping pipeline...")
    raise StopPipeline("data_loader.core.pipeline.steps.stoppipeline stopped current pipeline")
