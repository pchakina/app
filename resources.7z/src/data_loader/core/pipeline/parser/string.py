"""Context parser that adds the input argument string into the data_loader.core.pipeline context.

Takes any arbitrary string and adds it to the context dict as argString.

So a string like this "ham eggs bacon", will yield context:
{'argString': 'ham eggs bacon'}
"""
import logging

# getLogger will grab the parent logger context, so your loglevel and
# formatting will inherit correctly automatically from the data_loader.core.pipeline core.
logger = logging.getLogger(__name__)


def get_parsed_context(args):
    """Parse input context string and returns context as dictionary."""
    logger.debug("starting")
    if not args:
        logger.debug("pipeline invoked without context arg set. For "
                     "this string parser you're looking for something "
                     "like: data_loader.core.pipeline pipelinename spam and eggs"
                     )
        return {'argString': ''}

    # the string that's parsed from the input args is named argString
    return {'argString': ' '.join(args)}
