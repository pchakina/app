from data_loader.core.dto import Pipeline, Step


class StepContext:
    config: dict
    pipeline: Pipeline
    step_config: Step
