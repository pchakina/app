import json

from injector import Injector, singleton

from data_loader.core.json_mapper.json_mapper import JsonMapper


@singleton
class PayloadTransformer:

    def __init__(self):
        pass

    def transform(self, config: dict, payload: dict)->dict:
        return JsonMapper(payload).map(self.__to_transform_spec(config))

    def __to_transform_spec(self, config: dict)->dict:
        spec = dict()
        for key in config:
            spec[key] = [config[key]]

        return spec

if __name__ == '__main__':
    payload  = """
    {"person":
         {
            "name": "Juan dela Cruz",
            "age": 37 
        }
    }
    
    """

    with open("db.json", 'r') as json_file:
        json_data = json.load(json_file)

    config = dict()
    config["employee.name"] = 'person.name'

    transformer = PayloadTransformer()
    payload = transformer.transform(config, json.loads(payload))
    print(payload)