import json
from typing import Any
from jsonschema import validate, ValidationError
from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext
# from data_loader.config.schema import get_schema


@singleton
class ValidatorStep(BaseStep):
    type = "validator"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any)->str:
        print("In validator")
        print("received payload: " + json.dumps(payload))
        #       payload_schema = get_schema()
        try:
            #         validate(instance=payload, schema=payload_schema)
            print("JSON payload is valid!")
            payload["status"] = "Success"
        except ValidationError as e:
            error_message = f"JSON payload is invalid: {e.message}"
            print("JSON payload is invalid:", e.message)
            payload["status"] = "Failed"
            # raise ValueError(error_message)
        return "OK"
