import json
import httpx

from typing import Any

from injector import singleton

from data_loader.core.base_step import BaseStep
from data_loader.core.pipeline_context import PipelineContext
from data_loader.core.step_context import StepContext

@singleton
class HttpStep(BaseStep):
    type = "http"

    URL = "url"
    METHOD = "method"
    TRANSFORM_CONFIG = "transform_config"

    def process(self, pipeline_context: PipelineContext, step_context: StepContext, payload: Any):
        print("In HttpStep")
        print("received payload: " + json.dumps(payload))
        step_config = step_context.step_config
        if self.TRANSFORM_CONFIG in step_config.config:
            transform_config = step_config.config[self.TRANSFORM_CONFIG]
            payload = self.payload_transformer.transform(transform_config, payload)

        url = step_config.config[self.URL]
        method = step_config.config[self.METHOD].lower()
        json_payload = json.dumps(payload)
        with httpx.Client() as client:
            if method == "post":
                response = client.post(url, json=json_payload)
            elif method == "get":
                response = client.get(url)
            if response.status_code == 200:
                print(response.json())
                todo_data = response.json()
                payload["status"] = "Success"
            else:
                print("404 errrrrror")
                payload["status"] = "Resource Not Found"
            return response.json()

